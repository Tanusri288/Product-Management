package com.capg.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.capg.bean.Product;

public interface IProductService {

	public Product addProduct(Product prod);
	public List<Product> getAllProducts();
	public Product updateProduct(Integer pid,Product prod);
	public void deleteProduct(Integer pid);


}
