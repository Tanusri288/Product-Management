package com.capg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Component
@Entity
public class Product {

	@Id
	@NotNull
	private int pid;
	
	@NotNull
	@Size(min=3,max=20,message="name should not be empty")
	private String pname;
	
	@NotNull
	@Max(value=90000, message="price cannot exceed 90000")
	private double price;
	
	@NotNull
	@Size(min=10, max=10,message="Mobile no. should have 10 digits")
	private String Mno;
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	public String getMno() {
		return Mno;
	}
	public void setMno(String mno) {
		Mno = mno;
	}
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", price=" + price + ", Mno=" + Mno + "]";
	}
	
	
}
