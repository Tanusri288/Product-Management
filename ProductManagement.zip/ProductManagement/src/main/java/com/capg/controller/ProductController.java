package com.capg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Product;
import com.capg.service.IProductService;

@RestController
public class ProductController {

	@Autowired
	IProductService service;
	
	
	@GetMapping(path="/products",produces="application/json")
	public List<Product> getAllProducts() {
		
		return service.getAllProducts();
	}
	
	
	@PostMapping(path="/product",consumes="application/json")
	public String addProduct( @RequestBody Product prod) {
		
		 service.addProduct(prod);
		 return "added successfully";
	}
	

	@PutMapping(path="/product/{pid}", consumes="application/json")
	public String updateProduct(@PathVariable Integer pid, @RequestBody Product prod) {
		
		 service.updateProduct(pid, prod);
		 return "updated successfully";
	}
	
	
	
	
	@DeleteMapping(path="/product/{pid}")
	public String deleteProduct(@PathVariable Integer pid) {
		
		service.deleteProduct(pid);
		
		return "deleted successfully";
	}


}
