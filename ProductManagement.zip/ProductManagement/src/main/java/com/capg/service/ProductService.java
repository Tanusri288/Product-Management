package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Product;
import com.capg.dao.ProductRepository;

@Service
public class ProductService implements IProductService {

	@Autowired
	ProductRepository repo;

	@Override
	public Product addProduct(Product prod) {
		// TODO Auto-generated method stub
		return repo.save(prod);
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Product updateProduct(Integer pid, Product prod) {
		// TODO Auto-generated method stub
		Product findP = repo.findById(pid).orElse(null);
		return repo.save(prod);
	}

	@Override
	public void deleteProduct(Integer pid) {
		// TODO Auto-generated method stub
		repo.deleteById(pid);
	}

}
