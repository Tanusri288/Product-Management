package com.capg.exception;

public class EmployeeException extends Exception{

}
