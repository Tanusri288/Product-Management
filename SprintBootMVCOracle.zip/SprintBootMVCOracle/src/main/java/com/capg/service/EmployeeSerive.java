package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Employee;
import com.capg.dao.EmployeeRepository;

@Service
public class EmployeeSerive implements IEmployeeService {

	@Autowired
	EmployeeRepository repo;

	@Override
	public Employee getEmployeeById(int eid) {
		// TODO Auto-generated method stub

		return repo.findById(eid).orElse(null);
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub

		return repo.findAll();
	}

	@Override
	public void deleteEmployeeById(int eid) {
		// TODO Auto-generated method stub
		repo.deleteById(eid);
	}

	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return repo.save(emp);
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return repo.save(emp);
	}

	@Override
	public List<Employee> getEmployeeBySalary(double salary) {
		// TODO Auto-generated method stub
		return repo.findBySalary(salary);
	}

	@Override
	public List<Employee> getEmployeeByRange() {
		// TODO Auto-generated method stub
		return repo.findByRange();
	}

	

}
